'use strict';

const $ = id => document.getElementById(id);
const login = $('login');
const dashboard = $('dashboard');
let refreshTimer = null;
let roleMap = { 0:'NONE', 1:'VIP', 2:'MOD', 3:'KICK', 4:'FB', 5:'TT', 6:'YT', 7:'ADMIN', 255:'BANNED' };

async function api(url, options = {}) {
  const res = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  let data = {};
  try { data = await res.json(); } catch {}
  if (res.status === 401) throw new Error('UNAUTHORIZED');
  if (!res.ok || data.ok === false) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function fmtBytes(n) { return `${(Number(n || 0) / 1024 / 1024).toFixed(1)} MB`; }
function fmtUptime(sec) {
  sec = Math.floor(sec || 0);
  const d = Math.floor(sec / 86400); sec %= 86400;
  const h = Math.floor(sec / 3600); sec %= 3600;
  const m = Math.floor(sec / 60); sec %= 60;
  return `${d ? d + 'd ' : ''}${h ? h + 'h ' : ''}${m ? m + 'm ' : ''}${sec}s`;
}
function esc(s) {
  return String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function roleOptions(selected) {
  return Object.entries(roleMap).map(([id, name]) => `<option value="${esc(name)}" ${Number(id) === Number(selected) ? 'selected' : ''}>${esc(name)}</option>`).join('');
}

async function loadState() {
  try {
    const data = await api('/panel/api/state');
    roleMap = Object.fromEntries(Object.entries(data.roles || roleMap).map(([k,v]) => [k, v]));
    const s = data.server;
    $('playersCount').textContent = `${s.players} / ${s.maxPlayers}`;
    $('ram').textContent = fmtBytes(s.memory.rss);
    $('heap').textContent = fmtBytes(s.memory.heapUsed);
    $('uptime').textContent = fmtUptime(s.uptime);
    $('node').textContent = s.node;
    $('liveLabel').textContent = `${data.players.length} لاعب`;
    $('serverInfo').innerHTML = [
      ['HTTP', s.httpPort], ['WebSocket', s.wsPort], ['الحد الأقصى', s.maxPlayers],
      ['RSS', fmtBytes(s.memory.rss)], ['Heap', fmtBytes(s.memory.heapUsed)], ['Uptime', fmtUptime(s.uptime)]
    ].map(([a,b]) => `<div class="info"><b>${esc(a)}</b>${esc(b)}</div>`).join('');
    renderPlayers(data.players);
    renderMessages(data.messages);
  } catch (e) {
    if (e.message === 'UNAUTHORIZED') showLogin();
  }
}

function renderPlayers(players) {
  if (!players.length) {
    $('players').innerHTML = '<div class="empty">لا يوجد لاعبون متصلون.</div>';
    return;
  }
  $('players').innerHTML = players.map(p => `
    <article class="player ${p.isBot ? 'bot' : ''}">
      <div class="player-head"><span class="player-name">#${p.id} — ${esc(p.username)}</span><span class="role-tag">${esc(p.roleName || roleMap[p.role] || 'NONE')}</span>${p.isBot ? '<span class="bot-tag">BOT</span>' : ''}</div>
      <div class="meta">
        <div>Score<b>${p.score}</b></div><div>Length<b>${p.length}</b></div><div>Speed<b>${p.speed}</b></div>
        <div>X<b>${p.x}</b></div><div>Y<b>${p.y}</b></div><div>IP<b>${esc(p.ip || '—')}</b></div>
      </div>
      <div class="editor">
        <input data-k="username" maxlength="20" placeholder="اسم اللاعب" value="${esc(p.username)}">
        <input data-k="length" inputmode="decimal" placeholder="Length" value="${p.length}">
        <input data-k="speed" inputmode="decimal" placeholder="Speed multiplier" value="${p.speed}">
        <input data-k="skin_id" inputmode="numeric" placeholder="Skin" value="${p.skin_id}">
        <select data-k="role">${roleOptions(p.role)}</select>
      </div>
      <div class="controls">
        <button onclick="setPlayer(${p.id}, this)">حفظ التعديل</button>
        <button onclick="giveAbility(${p.id})">Ability</button>
        <button class="danger" onclick="killPlayer(${p.id})">قتل</button>
        <button class="secondary" onclick="${p.isBot ? `removeBot(${p.id})` : `kickPlayer(${p.id})`}">${p.isBot ? 'حذف Bot' : 'Kick'}</button>
      </div>
    </article>`).join('');
}

async function setPlayer(id, button) {
  const card = button.closest('.player');
  const body = {};
  card.querySelectorAll('[data-k]').forEach(i => body[i.dataset.k] = i.value);
  await action(`/panel/api/player/${id}/set`, body);
}
async function giveAbility(id) { await action(`/panel/api/player/${id}/ability`, { type: 0, charge: 100 }); }
async function killPlayer(id) { if (confirm(`قتل اللاعب #${id}؟`)) await action(`/panel/api/player/${id}/kill`, {}); }
async function kickPlayer(id) { if (confirm(`طرد اللاعب #${id}؟`)) await action(`/panel/api/player/${id}/kick`, {}); }
async function removeBot(id) { await action(`/panel/api/bots/${id}/remove`, {}); }

async function loadUsers() {
  try {
    const data = await api('/panel/api/users');
    $('users').innerHTML = data.users.map(u => `
      <tr data-user="${esc(u.user_id)}">
        <td><input data-k="username" maxlength="20" value="${esc(u.username)}"></td>
        <td><input data-k="level" inputmode="numeric" value="${u.level}"></td>
        <td><input data-k="coins" inputmode="numeric" value="${u.coins}"></td>
        <td><input data-k="points" inputmode="numeric" value="${u.points}"></td>
        <td><input data-k="kills" inputmode="numeric" value="${u.kills}"></td>
        <td><input data-k="headshots" inputmode="numeric" value="${u.headshots}"></td>
        <td><input data-k="skin_id" inputmode="numeric" value="${u.skin_id}"></td>
        <td><input data-k="hat_id" inputmode="numeric" value="${u.hat_id}"></td>
        <td><select data-k="role">${roleOptions(u.role)}</select></td>
        <td><input data-k="is_banned" type="checkbox" ${u.is_banned ? 'checked' : ''}></td>
        <td><button onclick="saveUser(this)">حفظ</button></td>
      </tr>`).join('');
  } catch (e) {
    if (e.message === 'UNAUTHORIZED') showLogin();
  }
}

async function saveUser(button) {
  const row = button.closest('tr');
  const body = {};
  row.querySelectorAll('[data-k]').forEach(i => body[i.dataset.k] = i.type === 'checkbox' ? i.checked : i.value);
  await action(`/panel/api/user/${encodeURIComponent(row.dataset.user)}/set`, body);
}

function renderMessages(messages) {
  $('messages').innerHTML = messages.length
    ? messages.map(m => `<div class="msg"><time>${esc(new Date(m.at).toLocaleString())}</time><span>${esc(m.message)}</span></div>`).join('')
    : '<div class="empty">السجل فارغ.</div>';
}

async function action(url, body) {
  try {
    await api(url, { method: 'POST', body: JSON.stringify(body) });
    await loadState();
    if (url.includes('/user/')) await loadUsers();
  } catch (e) {
    if (e.message === 'UNAUTHORIZED') showLogin();
    else alert(e.message);
  }
}

function showDashboard() {
  login.hidden = true;
  dashboard.hidden = false;
  loadState();
  loadUsers();
  clearInterval(refreshTimer);
  refreshTimer = setInterval(loadState, 2000);
}
function showLogin() {
  clearInterval(refreshTimer);
  dashboard.hidden = true;
  login.hidden = false;
}

$('loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  $('loginError').textContent = '';
  try {
    await api('/panel/api/login', { method: 'POST', body: JSON.stringify({ password: $('password').value }) });
    $('password').value = '';
    showDashboard();
  } catch {
    $('loginError').textContent = 'كلمة المرور غير صحيحة';
  }
});
$('refreshBtn').onclick = () => { loadState(); loadUsers(); };
$('logoutBtn').onclick = async () => { try { await api('/panel/api/logout', { method:'POST', body:'{}' }); } finally { showLogin(); } };
$('restartBtn').onclick = async () => { if (confirm('سيتم فصل كل اللاعبين وإعادة بناء عالم اللعبة. متأكد؟')) await action('/panel/api/restart-game', {}); };
$('addBot').onclick = async () => { await action('/panel/api/bots/add', { name: $('botName').value || 'BOT' }); };
$('clearMessages').onclick = async () => { if (confirm('مسح سجل الرسائل الوهمية القديم؟')) await action('/panel/api/messages/clear', {}); };

(async function init() {
  try { await api('/panel/api/state'); showDashboard(); }
  catch { showLogin(); }
})();
