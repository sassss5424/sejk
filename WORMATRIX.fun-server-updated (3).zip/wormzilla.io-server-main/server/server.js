'use strict';

const express = require('express');
const crypto = require('crypto');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const cfg = require('./config');
const db = require('./database');
const { encodeResponse } = require('./protocol');
const { verifyGoogleJWT, verifyTurnstile, validateUsername } = require('./auth');
const {
  startGameServer, createSession, getPlayerCount, getLivePlayers,
  adminKickPlayer, adminKillPlayer, adminSetPlayer, adminApplyUser, adminGrantAbility,
  adminAddBot, adminRemoveBot, adminResetGame,
} = require('./gameServer');

// ─── Init (async startup) ──────────────────────────────────────────────────
// db.init() is called in startServer() below

const app = express();
app.use(express.json({ limit: '256kb' }));
const upload = multer({ storage: multer.memoryStorage() });

// Serve static files from parent directory (client files)
const CLIENT_ROOT = path.join(__dirname, '..');
app.use(express.static(CLIENT_ROOT));

// ─── Helpers ───────────────────────────────────────────────────────────────

function getActiveServers() {
  return [
    {
      a: 'Local',
      b: `ws://localhost:${cfg.WS_PORT}`,
      c: getPlayerCount(),
      d: 'sg',
      e: 'as',
    },
  ];
}

function encodedResponse(res, obj) {
  res.type('text/plain').send(encodeResponse(JSON.stringify(obj)));
}

function getIP(req) {
  return (req.headers['cf-connecting-ip'] ||
    req.headers['x-forwarded-for'] ||
    req.socket.remoteAddress || '').split(',')[0].trim();
}

// ─── Rate limiting (simple in-memory) ─────────────────────────────────────

const ipRequestLog = new Map();
function rateLimit(req, res, next) {
  const ip = getIP(req);
  const now = Date.now();
  const log = ipRequestLog.get(ip) || [];
  const recent = log.filter(t => now - t < 1000);
  recent.push(now);
  ipRequestLog.set(ip, recent);
  if (recent.length > 10) return res.status(429).send('Too Many Requests');
  next();
}

// ─── Admin panel ───────────────────────────────────────────────────────────

const adminSessions = new Map();
const adminMessages = [];

function adminHash(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function safeEqualHex(a, b) {
  const aa = Buffer.from(a, 'hex');
  const bb = Buffer.from(b, 'hex');
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function getAdminSession(req) {
  const raw = req.headers.cookie || '';
  const match = raw.match(/(?:^|;\s*)wmx_admin=([^;]+)/);
  if (!match) return null;
  const token = decodeURIComponent(match[1]);
  const session = adminSessions.get(token);
  if (!session || Date.now() > session.expiresAt) {
    if (session) adminSessions.delete(token);
    return null;
  }
  session.expiresAt = Date.now() + cfg.PANEL_SESSION_TTL_MS;
  return session;
}

function requireAdmin(req, res, next) {
  if (!getAdminSession(req)) return res.status(401).json({ ok: false, error: 'Unauthorized' });
  next();
}

function adminLog(message) {
  adminMessages.unshift({ at: new Date().toISOString(), message: String(message) });
  if (adminMessages.length > 300) adminMessages.length = 300;
}

app.post('/panel/api/login', rateLimit, (req, res) => {
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const supplied = adminHash(password);
  if (!safeEqualHex(supplied, cfg.PANEL_PASSWORD_SHA256)) {
    return res.status(401).json({ ok: false, error: 'Wrong password' });
  }
  const token = crypto.randomBytes(32).toString('hex');
  adminSessions.set(token, { createdAt: Date.now(), expiresAt: Date.now() + cfg.PANEL_SESSION_TTL_MS });
  res.setHeader('Set-Cookie', `wmx_admin=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/panel`);
  adminLog('Admin panel login');
  res.json({ ok: true });
});

app.post('/panel/api/logout', requireAdmin, (req, res) => {
  const raw = req.headers.cookie || '';
  const match = raw.match(/(?:^|;\s*)wmx_admin=([^;]+)/);
  if (match) adminSessions.delete(decodeURIComponent(match[1]));
  res.setHeader('Set-Cookie', 'wmx_admin=; HttpOnly; SameSite=Strict; Path=/panel; Max-Age=0');
  res.json({ ok: true });
});

app.get('/panel/api/state', requireAdmin, (req, res) => {
  const mem = process.memoryUsage();
  const players = getLivePlayers();
  res.json({
    ok: true,
    server: {
      name: 'WORMATRIX.fun',
      httpPort: Number(process.env.PORT || cfg.HTTP_PORT),
      wsPort: Number(process.env.WS_PORT || cfg.WS_PORT),
      maxPlayers: cfg.MAX_PLAYERS,
      players: players.length,
      uptime: process.uptime(),
      node: process.version,
      memory: {
        rss: mem.rss,
        heapUsed: mem.heapUsed,
        heapTotal: mem.heapTotal,
        external: mem.external,
        arrayBuffers: mem.arrayBuffers,
      },
    },
    players,
    roles: cfg.ROLE_NAMES,
    messages: adminMessages.slice(0, 100),
  });
});

app.get('/panel/api/users', requireAdmin, (req, res) => {
  res.json({ ok: true, users: db.getAdminUsers(500) });
});

app.post('/panel/api/player/:id/kick', requireAdmin, (req, res) => {
  const ok = adminKickPlayer(req.params.id);
  if (ok) adminLog(`Kick player #${req.params.id}`);
  res.json({ ok });
});

app.post('/panel/api/player/:id/kill', requireAdmin, (req, res) => {
  const ok = adminKillPlayer(req.params.id);
  if (ok) adminLog(`Kill player #${req.params.id}`);
  res.json({ ok });
});

app.post('/panel/api/player/:id/set', requireAdmin, (req, res) => {
  const patch = req.body || {};
  try {
    const ok = adminSetPlayer(req.params.id, patch);
    if (ok) {
      const live = getLivePlayers().find(p => String(p.id) === String(req.params.id));
      if (live?.userId) {
        const persistent = {};
        for (const key of ['username','skin_id','eyes_id','mouth_id','hat_id','glasses_id','role']) {
          if (patch[key] !== undefined) persistent[key] = patch[key];
        }
        if (Object.keys(persistent).length) db.updateAdminUser(live.userId, persistent);
      }
      adminLog(`Updated live player #${req.params.id}`);
    }
    res.json({ ok });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message || 'Invalid player update' });
  }
});

app.post('/panel/api/player/:id/ability', requireAdmin, (req, res) => {
  const ok = adminGrantAbility(req.params.id, req.body?.type, req.body?.charge);
  if (ok) adminLog(`Granted ability to player #${req.params.id}`);
  res.json({ ok });
});

app.post('/panel/api/user/:id/set', requireAdmin, (req, res) => {
  const patch = { ...(req.body || {}) };
  if (patch.role === 'BANNED') patch.is_banned = true;
  if (patch.is_banned === false && String(patch.role || '').toUpperCase() === 'BANNED') patch.role = 'NONE';
  try {
    const ok = db.updateAdminUser(req.params.id, patch);
    if (ok) {
      adminApplyUser(req.params.id, patch);
      adminLog(`Updated account ${req.params.id}`);
    }
    res.json({ ok });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message || 'Invalid account update' });
  }
});

app.post('/panel/api/bots/add', requireAdmin, (req, res) => {
  const id = adminAddBot(req.body?.name || 'BOT');
  if (!id) return res.status(409).json({ ok: false, error: 'Server full' });
  adminLog(`Added test bot #${id}`);
  res.json({ ok: true, id });
});

app.post('/panel/api/bots/:id/remove', requireAdmin, (req, res) => {
  const ok = adminRemoveBot(req.params.id);
  if (ok) adminLog(`Removed test bot #${req.params.id}`);
  res.json({ ok });
});

app.post('/panel/api/restart-game', requireAdmin, (req, res) => {
  adminResetGame();
  adminLog('Restarted game world and disconnected all players');
  res.json({ ok: true });
});

app.post('/panel/api/messages/clear', requireAdmin, (req, res) => {
  adminMessages.length = 0;
  res.json({ ok: true });
});

app.post('/panel/api/logs/clear', requireAdmin, (req, res) => {
  adminMessages.length = 0;
  res.json({ ok: true });
});

// ─── Routes ────────────────────────────────────────────────────────────────

// Serve registry file directly (already XOR-encoded)
app.get('/media/registry.wormzilla', (req, res) => {
  res.sendFile(path.join(CLIENT_ROOT, 'media', 'registry.wormzilla'));
});

// Also serve the one in /js/
app.get('/js/registry.wormzilla', (req, res) => {
  res.sendFile(path.join(CLIENT_ROOT, 'js', 'registry.wormzilla'));
});

// ─── GET /api/login/:token ─────────────────────────────────────────────────

app.get('/api/login/:token', rateLimit, (req, res) => {
  try {
    const user = db.findByToken(req.params.token);
    if (!user) {
      return encodedResponse(res, { code: 404, a: 'Token not found.' });
    }
    if (user.is_banned) {
      return encodedResponse(res, { code: 201, a: user.ban_reason || 'You are banned.' });
    }
    const data = db.formatUserResponse(user, getActiveServers());
    return encodedResponse(res, { code: 200, data });
  } catch (err) {
    console.error('[/api/login]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/google_login/:google_jwt ────────────────────────────────────

app.post('/api/google_login/:google_jwt', rateLimit, async (req, res) => {
  try {
    const payload = await verifyGoogleJWT(req.params.google_jwt);
    if (!payload) {
      return encodedResponse(res, { code: 400, a: 'Invalid Google token.' });
    }

    const user = db.findByGoogleId(payload.sub);
    if (!user) {
      return encodedResponse(res, { code: 202 }); // not registered
    }
    if (user.is_banned) {
      return encodedResponse(res, { code: 201, a: user.ban_reason || 'You are banned.' });
    }
    const data = db.formatUserResponse(user, getActiveServers());
    return encodedResponse(res, { code: 200, data });
  } catch (err) {
    console.error('[/api/google_login]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/register/:google_jwt ───────────────────────────────────────

app.post('/api/register/:google_jwt', rateLimit, upload.none(), async (req, res) => {
  try {
    const { username, cf_turn } = req.body;

    const turnstileOk = await verifyTurnstile(cf_turn, getIP(req));
    if (!turnstileOk) {
      return encodedResponse(res, { code: 400, a: 'Captcha failed.' });
    }

    const validation = validateUsername(username);
    if (validation === 'flagged') return encodedResponse(res, { code: 203 });
    if (validation !== 'ok') return encodedResponse(res, { code: 400, a: 'Invalid username.' });

    const payload = await verifyGoogleJWT(req.params.google_jwt);
    if (!payload) return encodedResponse(res, { code: 400, a: 'Invalid Google token.' });

    const existing = db.findByUsername(username.trim());
    if (existing) return encodedResponse(res, { code: 201 });

    const user = db.createUser({
      google_id: payload.sub,
      username: username.trim(),
      mail: payload.email,
    });

    const data = db.formatUserResponse(user, getActiveServers());
    return encodedResponse(res, { code: 200, data });
  } catch (err) {
    if (err.message && err.message.includes('UNIQUE')) {
      return encodedResponse(res, { code: 201 }); // username taken
    }
    console.error('[/api/register]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/key_login/ ──────────────────────────────────────────────────

app.post('/api/key_login/', rateLimit, upload.none(), (req, res) => {
  try {
    const key = (req.body.key || '').trim();
    if (!key) return encodedResponse(res, { code: 202 });

    const user = db.findByToken(key);
    if (!user || user.is_banned) {
      return encodedResponse(res, { code: 202 });
    }
    const data = db.formatUserResponse(user, getActiveServers());
    return encodedResponse(res, { code: 200, data });
  } catch (err) {
    console.error('[/api/key_login]', err);
    res.status(500).send('Internal error');
  }
});
app.post('/api/guest_login/', rateLimit, upload.none(), (req, res) => {
  try {
    let user = null;
    for (let attempt = 0; attempt < 5 && !user; attempt++) {
      const username = 'Guest-' + Math.random().toString(36).slice(2, 8);
      try {
        user = db.createUser({ google_id: null, username, mail: null });
      } catch (e) {
        if (!(e.message && e.message.includes('UNIQUE'))) throw e;
      }
    }
    if (!user) return encodedResponse(res, { code: 500, a: 'Could not create guest.' });
 
    const data = db.formatUserResponse(user, getActiveServers());
    return encodedResponse(res, { code: 200, data });
  } catch (err) {
    console.error('[/api/guest_login]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/start_game/ ────────────────────────────────────────────────

app.post('/api/start_game/', upload.none(), (req, res) => {
  try {
    const token = req.body.token || '';
    if (!token) return res.json({ code: 401 });

    const user = db.findByToken(token);
    if (!user || user.is_banned) {
      return res.json({ code: 401 });
    }

    // Create a session so game server knows this user
    createSession(token, user.user_id);

    return res.json({
      code: 200,
      url: `ws://localhost:${cfg.WS_PORT}`,
      v: 4,
      t: Date.now(),
    });
  } catch (err) {
    console.error('[/api/start_game]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/get_leaderboard/ ───────────────────────────────────────────

app.post('/api/get_leaderboard/', upload.none(), (req, res) => {
  try {
    const token = req.body.a || '';
    const type = req.body.b || 'score';

    const user = db.findByToken(token);
    const list = db.getLeaderboard(type);

    return res.json({
      list: list.map(u => ({
        id: u.user_id,
        username: u.username,
        kills: u.kills,
        headshots: u.headshots,
        max_score: Math.floor(u.max_score * 50),
        level: u.level,
      })),
      me: user ? user.user_id : null,
    });
  } catch (err) {
    console.error('[/api/get_leaderboard]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/nick-change/ ───────────────────────────────────────────────

app.post('/api/nick-change/', upload.none(), async (req, res) => {
  try {
    const { token, username, cf_turn } = req.body;

    const turnstileOk = await verifyTurnstile(cf_turn, getIP(req));
    if (!turnstileOk) return res.json({ code: 400 });

    const user = db.findByToken(token || '');
    if (!user) return res.json({ code: 201 });
    if (user.name_cards <= 0) return res.json({ code: 202 });

    const validation = validateUsername(username);
    if (validation === 'flagged') return res.json({ code: 203 });
    if (validation !== 'ok') return res.json({ code: 400 });

    const existing = db.findByUsername(username.trim());
    if (existing && existing.user_id !== user.user_id) return res.json({ code: 201 });

    const ok = db.updateUsername(user.user_id, username.trim());
    return res.json({ code: ok ? 200 : 202 });
  } catch (err) {
    console.error('[/api/nick-change]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/gift_vip/ ──────────────────────────────────────────────────

app.post('/api/gift_vip/', upload.none(), (req, res) => {
  try {
    const tokenA = req.body.a || '';
    const usernameB = req.body.b || '';

    const giver = db.findByToken(tokenA);
    if (!giver) return res.json({ code: 201 });

    const receiver = db.findByUsername(usernameB);
    if (!receiver) return res.json({ code: 202 });

    return res.json({ code: 200, receiver_id: receiver.user_id });
  } catch (err) {
    console.error('[/api/gift_vip]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/verify_purchase/ ───────────────────────────────────────────

app.post('/api/verify_purchase/', upload.none(), (req, res) => {
  try {
    const { token, product_token, product_id, gift_id } = req.body;
    const user = db.findByToken(token || '');
    if (!user) return res.json({ code: 201 });

    // Grant VIP based on product
    const targetUser = gift_id ? db.findByUserId(gift_id) : user;
    if (!targetUser) return res.json({ code: 202 });

    if (product_id && product_id.includes('vip')) {
      db.grantVip(targetUser.user_id, 1);
    }

    return res.json({ code: 200 });
  } catch (err) {
    console.error('[/api/verify_purchase]', err);
    res.status(500).send('Internal error');
  }
});

// ─── POST /api/buy-property/:token ────────────────────────────────────────

app.post('/api/buy-property/:token', upload.none(), (req, res) => {
  try {
    const user = db.findByToken(req.params.token);
    if (!user) return res.status(401).send('Unauthorized');

    const itemId = parseInt(req.query.id, 10);
    const itemType = req.query.type;

    // Simplified: allow purchase if coins >= price
    // In production, look up price from registry
    const price = 0; // TODO: parse from registry

    const ownedKey = `owned_${itemType}s`;
    const owned = db.safeJson(user[ownedKey] || '[]', []);
    if (!owned.includes(String(itemId))) owned.push(String(itemId));

    db.run(`UPDATE users SET ${ownedKey}=?, coins=coins-? WHERE user_id=? AND coins>=?`,
      [JSON.stringify(owned), price, user.user_id, price]);

    res.status(200).send('ok');
  } catch (err) {
    console.error('[/api/buy-property]', err);
    res.status(500).send('Internal error');
  }
});

// ─── GET /ads (anti-adblock) ──────────────────────────────────────────────

app.get('/ads', (req, res) => {
  res.status(200).send('');
});

// ─── Catch-all: serve index.html ──────────────────────────────────────────

app.get('*', (req, res) => {
  res.sendFile(path.join(CLIENT_ROOT, 'index.html'));
});

// ─── Start ────────────────────────────────────────────────────────────────

async function startServer() {
  const HTTP_PORT = process.env.PORT || cfg.HTTP_PORT;
  const WS_PORT = process.env.WS_PORT || cfg.WS_PORT;

  await db.init();
  console.log('[DB] Database initialized');

  app.listen(HTTP_PORT, () => {
    console.log(`[HTTP] Server listening on http://localhost:${HTTP_PORT}`);
  });

  startGameServer(Number(WS_PORT));
}

startServer().catch(err => {
  console.error('[FATAL]', err);
  process.exit(1);
});
